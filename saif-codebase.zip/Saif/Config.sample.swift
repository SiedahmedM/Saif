import Foundation

enum ConfigSample {
    // Replace with your project id and keys, then copy to Config.swift.
    static let supabaseURL = "https://YOUR_PROJECT_ID.supabase.co"
    static let supabaseAnonKey = "YOUR_ANON_KEY_HERE"
    static let openAIKey = "sk-YOUR_OPENAI_KEY_HERE"
}
