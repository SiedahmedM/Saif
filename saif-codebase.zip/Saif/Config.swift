import Foundation

enum Config {
    static let supabaseURL = "https://jgjlmlcbyediiokazaru.supabase.co"
    static let supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpnamxtbGNieWVkaWlva2F6YXJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE3ODE0OTAsImV4cCI6MjA3NzM1NzQ5MH0.GGlv3LHU5OpSnzMQWdJlU6ar3qg92NVSE6X0swvfyyM"
    // Do NOT commit this file. It's in .gitignore.
    static let openAIKey = "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"
}
